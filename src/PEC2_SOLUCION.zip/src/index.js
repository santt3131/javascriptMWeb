import { init } from "./pec2";

console.log("Bienvenido a JS para programadores");

init();

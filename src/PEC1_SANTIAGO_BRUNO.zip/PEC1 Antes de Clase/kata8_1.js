var objectoArbol = {
  especie: 'manzano',
  fruta: 'manzana',
  obtenerFruta: function obtenerFruta() {
    return this.fruta;
  }
};

export default objectoArbol;

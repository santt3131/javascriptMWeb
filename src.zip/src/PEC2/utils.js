export function prepareStandings(datosDeLaApli) {
  //preparar datosDeLaApi
  const standings = new Clasificacion(datosPreparados);
}

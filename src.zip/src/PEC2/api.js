import { prepareStandings } from './utils';

export function getStandings() {
  // obtener datos de la api
  prepareStandings(datosDeLaApi);
}

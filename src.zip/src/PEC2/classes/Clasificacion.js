class Clasificacion {
  constructor(datosPreparados) {
    //implementar constructor
  }

  //implementar metodos
}

export default function init() {
  console.log('Saludos desde la PEC2');
  //obtener datos desde la API
  async function connect() {
    const headers = new Headers();
    headers.append('X-Auth-Token', 'c76c8149aa4c4a36b55cf2040b5d2081');

    try {
      let url = 'https://api.football-data.org/v2/competitions/2014/stadings';
      const response = await fetch(url, { method: 'GET', headers });
      console.log(await response.json());
    } catch (error) {
      console.log('fetch failed', error);
    }
  }

  connect();
}

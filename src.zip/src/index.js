import init from './PEC2';

console.log('Bienvenido a JS para programadores');

init();

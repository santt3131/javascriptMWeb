export default class MiArbol {
  constructor(especie, fruta) {
    this.especie = especie;
    this.fruta = fruta;
  }

  obtenerFruta() {
    return this.fruta;
  }
}
